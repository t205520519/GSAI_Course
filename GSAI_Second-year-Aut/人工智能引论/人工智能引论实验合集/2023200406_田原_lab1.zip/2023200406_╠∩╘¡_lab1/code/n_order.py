import numpy as np
import random
import heapq

class PuzzleBoardState(object):
    """ 华容道棋盘类
    """
    def __init__(self, dim=5, random_seed=2022, data=None, parent=None, gn=0, hn=0):
        """ 根据给定随机数 随机初始化一个可解的华容道问题 
            dim         :   int, 华容道棋盘维度(阶数)    
            random_seed :   int, 创建随机棋盘的随机种子    
            data        :   numpy.ndarray (dim*dim), 创建棋盘的数据
        """
        self.dim = dim
        self.default_dst_data = np.arange(1, dim * dim).tolist() + [0]  # 生成目标状态
        self.default_dst_data = np.array(self.default_dst_data).reshape((dim, dim))

        if data is None:
            init_solvable = False
            init_count = 0
            while not init_solvable and init_count < 500:
                init_data = self._get_random_data(random_seed=random_seed + init_count)
                init_count += 1
                init_solvable = self._if_solvable(init_data, self.default_dst_data)
            data = init_data

        self.data = data
        self.parent = parent
        self.piece_x, self.piece_y = self._get_piece_index()
        self.gn = gn
        self.hn = hn
        self.fn = self.hn + self.gn

    def __lt__(self, other):
        return self.fn < other.fn

    def eq(self, other):
        return self.get_data_hash() == other.get_data_hash()

    def __ne__(self, other):
        return not self.__eq__(other)

    def _get_random_data(self, random_seed):
        """ 根据random_seed 生成一个dim*dim的华容道棋盘数据 """
        random.seed(random_seed)
        init_data = list(range(self.dim**2))
        random.shuffle(init_data)
        init_data = np.array(init_data).reshape((self.dim, self.dim))

        return init_data

    def _get_piece_index(self):
        """ 返回当前将牌(空格)位置 """
        index = np.argsort(self.data.flatten())[0]
        return index // self.dim, index % self.dim

    def _inverse_num(self, puzzle_board_data):
        flatten_data = puzzle_board_data.flatten()
        res = 0
        for i in range(len(flatten_data)):
            if flatten_data[i] == 0:
                continue
            for j in range(i):
                if flatten_data[j] > flatten_data[i]:
                    res += 1
        return res

    def _if_solvable(self, src_data, dst_data):
        """ 判断一个(src_data => dst_data)的华容道问题是否可解 """
        if(self.dim%2==0):
            assert src_data.shape == dst_data.shape, "src_data and dst_data should share same shape."
            line=0
            for i in range(self.dim):
                for j in range(self.dim):
                    if src_data[i][j] ==0:
                        line=i
                        break
            inverse_num_sum = self._inverse_num(src_data) + self._inverse_num(dst_data)+line+1
            return inverse_num_sum % 2 == 0
        else:
            assert src_data.shape == dst_data.shape, "src_data and dst_data should share same shape."
            inverse_num_sum = self._inverse_num(src_data) + self._inverse_num(dst_data)

            return inverse_num_sum%2 == 0

    def is_final(self):
        """ 判断棋盘当前状态是否为目标终止状态 """
        flatten_data = self.data.flatten()
        if flatten_data[-1] != 0:
            return False
        for i in range(self.dim**2 - 1):
            if flatten_data[i] != (i + 1):
                return False
        return True

    def next_states(self):
        """ 返回当前状态的相邻状态 """
        res = []
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            x2, y2 = self.piece_x + dx, self.piece_y + dy
            if 0 <= x2 < self.dim and 0 <= y2 < self.dim:
                new_data = self.data.copy()
                new_data[self.piece_x][self.piece_y] = new_data[x2][y2]
                new_data[x2][y2] = 0
                gn = self.gn + 1
                hn = self.heuristic()
                res.append(PuzzleBoardState(data=new_data, parent=self, gn=gn, hn=hn))
        return res

    def get_data(self):
        """ 返回当前棋盘状态数据 """
        return self.data

    def get_data_hash(self):
        """ 返回基于当前状态数据的哈希值 """
        return hash(tuple(self.data.flatten()))

    def get_parent(self):
        """ 返回当前状态的父节点状态 """
        return self.parent

    def heuristic(self):
        curstate = self.data
        endstate = self.default_dst_data
        dist = 0
        N = len(curstate)
        for i in range(N):
            for j in range(N):
                if curstate[i][j] == endstate[i][j]:
                    continue
                num = curstate[i][j]
                if num == 0:
                    x, y = N - 1, N - 1
                else:
                    x = (num - 1) // N
                    y = (num - 1) % N
                dist += (abs(x - i) + abs(y - j))
        return dist

def bfs(puzzle_board_state):
    """ 已实现的华容道广度优先算法 """
    visited = set()
    from collections import deque
    queue = deque()
    queue.append((0, puzzle_board_state))
    visited.add(puzzle_board_state.get_data_hash())

    ans = []
    while queue:
        (now, cur_state) = queue.popleft()
        if cur_state.is_final():
            while cur_state.get_parent() is not None:
                ans.append(cur_state)
                cur_state = cur_state.get_parent()
            ans.append(cur_state)
            break

        next_states = cur_state.next_states()
        for next_state in next_states:
            if next_state.get_data_hash() in visited:
                continue
            visited.add(next_state.get_data_hash())
            queue.append((now + 1, next_state))

    return ans

def astar(puzzle_board_state):
    """ A*算法实现 """
    open_set = []
    closed_set = set()
    cur_state = puzzle_board_state
    ans = []
    open_set.append(cur_state)
    heapq.heapify(open_set)
    closed_set.add(cur_state.get_data_hash())

    #stop=1
    while len(open_set):
        top = heapq.heappop(open_set)        
        if top.is_final():
            while top.get_parent() is not None:
                ans.append(top)
                top = top.get_parent()
            break 
        
        for next_state in top.next_states():
            if next_state.get_data_hash() not in closed_set:
                closed_set.add(next_state.get_data_hash())
                heapq.heappush(open_set, next_state)

    return ans[::-1]

if __name__ == "__main__":
    # 示例：测试一个4阶的华容道棋盘
    test_data =np.array([[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,0],[16,17,18,19,15],[21,22,23,24,20]])
    test_board = PuzzleBoardState(data=test_data)
    res = astar(test_board)
    for state in res:
        print(state.data)
