import kagglehub

# Download latest version
path = kagglehub.dataset_download("mattop/ai-cat-and-dog-images-dalle-mini")

print("Path to dataset files:", path)