import requests
import os
import pickle
names=os.listdir("2023200406+田原+实验3\\images")
ls=[]
for name in names:
    files = {"image": open("2023200406+田原+实验3\\images\\"+name, "rb")}
    url = "http://bl.mmd.ac.cn:8889/image_query"

    r = requests.post(url, files=files)
    ls.append(r.json()['embedding'])
with open("2023200406+田原+实验3\\"+"datas.pkl","wb") as f:
    pickle.dump(ls,f)
with open("2023200406+田原+实验3\\"+"datas.pkl","rb") as f:
    data = pickle.load(f)
    print(len(data))