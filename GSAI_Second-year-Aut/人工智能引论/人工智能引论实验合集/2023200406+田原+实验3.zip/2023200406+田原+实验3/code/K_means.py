import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
import pickle
class KMeans:
    def __init__(self, n_clusters=3, max_iter=100):
        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.centroids = None

    def _init_centroids(self, X):
        indices = np.random.choice(X.shape[0], size=self.n_clusters, replace=False)#choice函数从range(X.shape[0])中随机选择n_clusters个索引，replace为False表示不重复选择
        return X[indices]
    def fit(self, X):
        self.centroids = self._init_centroids(X)

        for _ in range(self.max_iter):
            distances = self._compute_cosine_distances(X)
            closest = np.argmin(distances, axis=1)
            new_centroids = np.array([X[closest == k].mean(axis=0) for k in range(self.n_clusters)])#采用布尔索引的方式找到每个样本所属的类别
            if np.all(np.linalg.norm(self.centroids - new_centroids, axis=1) < 1e-4):
                break
            self.centroids = new_centroids

        return self

    def predict(self, X):
        distances = self._compute_cosine_distances(X)#在我们得到聚类中心后可以实现对测试数据进行分类
        return np.argmin(distances, axis=1)

    def _compute_cosine_distances(self, X):
        X_norm = X / np.linalg.norm(X, axis=1, keepdims=True)#linalg.norm计算向量的范数（一般为F2范数即欧式距离），keepdims为True表示保持向量的维度本题为返回n*1而不是n
        centroids_norm = self.centroids / np.linalg.norm(self.centroids, axis=1, keepdims=True)
        cosine_similarities = X_norm @ centroids_norm.T#矩阵乘法,返回一个数据个数*n_clusters的矩阵
        return 1 - cosine_similarities

def visualize(X, labels, centroids):
    pca = PCA(n_components=2)
    X_reduced = pca.fit_transform(X)
    centroids_reduced = pca.transform(centroids)

    plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=labels, s=50, cmap='viridis')
    plt.scatter(centroids_reduced[:, 0], centroids_reduced[:, 1], c='red', s=200, alpha=0.75)
    plt.title('K-means Clustering on High-dimensional Data')
    plt.show()

if __name__ == "__main__":
    with open("2023200406+田原+实验3\\"+"datas.pkl","rb") as f:
        datalist = pickle.load(f)
        datalist = np.array(datalist)
    # 实例化并训练 KMeans 模型
    n_clusters = 2#共有猫和狗两类数据
    kmeans = KMeans(n_clusters=n_clusters)
    kmeans.fit(datalist)
    predictions = kmeans.predict(datalist)
    visualize(datalist, predictions, kmeans.centroids)

    # 计算轮廓系数（余弦距离）
    score = silhouette_score(datalist, predictions, metric='cosine')#利用轮廓系数评估聚类结果(m(b)-m(a)/max(m(a),m(b)))
    print(f'Silhouette Score (Cosine Distance): {score:.2f}')
