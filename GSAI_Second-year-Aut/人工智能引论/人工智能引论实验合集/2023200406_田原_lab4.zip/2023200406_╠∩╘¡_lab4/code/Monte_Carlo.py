import random
def monte_carlo_pi(num_points):
    inside_circle = 0

    for _ in range(num_points):
        # 随机生成 [0, 1] 范围内的x, y坐标
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)
        
        # 判断点是否在单位圆内
        if x**2 + y**2 <= 1:
            inside_circle += 1

    # 圆内点与总点的比值接近 π/4，因此π ≈ 4 * (inside_circle / num_points)
    pi_estimate = 4 * (inside_circle / num_points)
    return pi_estimate
num_points = 10000000
estimated_pi = monte_carlo_pi(num_points)

print(f"使用 {num_points} 个点估计的圆周率：{estimated_pi}")
